<nav class="navbar glass">
    <div class="nav-container">
        <div class="nav-logo">
            <a href="<?php echo e(route('welcome')); ?>" class="logo-text">#XV<span class="gold-dot">.</span></a>
        </div>
        <ul class="nav-links">
            <li><a href="<?php echo e(route('welcome')); ?>" class="nav-link <?php echo e(request()->routeIs('welcome') ? 'active' : ''); ?>">Accueil</a></li>
            <li><a href="<?php echo e(route('skills')); ?>" class="nav-link <?php echo e(request()->routeIs('skills') ? 'active' : ''); ?>">Compétences</a></li>
            <li><a href="<?php echo e(route('projects')); ?>" class="nav-link <?php echo e(request()->routeIs('projects') ? 'active' : ''); ?>">Projets</a></li>
            <li><a href="<?php echo e(route('contact')); ?>" class="nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">Contact</a></li>
        </ul>
        <div class="nav-toggle" id="navToggle"><i class="fas fa-bars"></i></div>
    </div>
</nav><?php /**PATH C:\oradi\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>