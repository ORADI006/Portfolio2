

<?php $__env->startSection('title', 'Projets'); ?>

<?php $__env->startSection('content'); ?>
<main class="main-content">
    <section class="page-header reveal">
        <h1 class="page-title">projets <span class="gold-text">récents</span></h1>
        <div class="title-underline"></div>
        <p class="header-sub">inspirés par une approche GitHub · chaque carte brille</p>
    </section>

    <!-- grille type repo github -->
    <section class="projects-grid reveal">
        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="project-card glass-card glow-hover">
            <div class="project-header">
                <i class="fas <?php echo e($project->icon); ?> gold-icon"></i>
                <h3><?php echo e($project->title); ?></h3>
            </div>
            <p class="project-desc"><?php echo e($project->description); ?></p>
            <div class="project-tech">
                <?php
                    $technologies = explode(',', $project->technologies);
                ?>
                <?php $__currentLoopData = $technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e(trim($tech)); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="project-footer">
                <span class="project-stars"><i class="far fa-star"></i> <?php echo e($project->stars); ?></span>
                <a href="<?php echo e($project->link); ?>" class="project-link"><i class="fas fa-external-link-alt"></i> Voir</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Aucun projet trouvé.</p>
        <?php endif; ?>
    </section>

    <!-- call to action subtil -->
    <div class="more-projects reveal">
        <a href="#" class="btn-glass btn-gold-glow"><i class="fab fa-github"></i> Plus sur GitHub</a>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\oradi\resources\views/projects.blade.php ENDPATH**/ ?>