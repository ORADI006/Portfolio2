<?php $__env->startSection('content'); ?>
<header>
    <img src="<?php echo e(asset('images/1772031940336.jpg')); ?>" alt="Photo de profil">
    <h1>Ingénieur en Intelligence Artificielle</h1>
</header>

<section>
    <h2>À propos de moi</h2>
    <p>
        Je suis ingénieur en intelligence artificielle, expérimenté dans le domaine de la robotique.
        Je suis passionné par le design et les systèmes embarqués, et j’aime relever des défis
        technologiques pour créer des solutions innovantes.
    </p>
</section>

<section>
    <h2>Compétences</h2>
    <ul>
        <li>Programmation : Python, C++, JavaScript</li>
        <li>Apprentissage automatique et deep learning</li>
        <li>Développement web (HTML, CSS, React)</li>
        <li>Systèmes embarqués et IoT</li>
        <li>Conception et modélisation 3D</li>
        <li>Bases de données (SQL, NoSQL)</li>
        <li>Outils de versioning (Git, GitHub)</li>
    </ul>
</section>

<section>
    <h2>Projets</h2>
    <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="project-card">
            <?php if($project->image_url): ?>
                <img src="<?php echo e(asset($project->image_url)); ?>" alt="<?php echo e($project->title); ?>">
            <?php endif; ?>
            <h3><?php echo e($project->title); ?></h3>
            <p><?php echo e($project->description); ?></p>
            <a href="<?php echo e($project->link); ?>" class="btn-submit">Voir le projet</a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Aucun projet trouvé.</p>
    <?php endif; ?>
</section>

<section>
    <h2>Contact</h2>
    <form action="<?php echo e(route('messages.store')); ?>" method="POST" class="contact-form">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Nom :</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="email">Email :</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="message">Message :</label>
            <textarea id="message" name="message" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn-submit">Envoyer</button>
    </form>

    <?php if(session('success')): ?>
        <div class="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
</section>

<footer>
    <p>© 2026 - Mon Portfolio</p>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\oradi\resources\views/welcome.blade.php ENDPATH**/ ?>