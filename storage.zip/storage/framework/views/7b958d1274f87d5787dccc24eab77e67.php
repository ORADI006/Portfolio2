

<?php $__env->startSection('title', 'Contact'); ?>

<?php $__env->startSection('content'); ?>
<main class="main-content">
    <section class="page-header reveal">
        <h1 class="page-title">me <span class="gold-text">contacter</span></h1>
        <div class="title-underline"></div>
        <p class="header-sub">pour des collaborations, questions ou opportunités</p>
    </section>

    <section class="contact-section reveal">
        <div class="contact-form glass-card">
            <form action="<?php echo e(route('messages.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Nom</label>
                    <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" required><?php echo e(old('message')); ?></textarea>
                </div>
                <button type="submit" class="btn-glass btn-gold-glow">
                    <span>Envoyer le message</span>
                    <i class="fas fa-paper-plane"></i>
                </button>
            </form>
        </div>

        <?php if(session('success')): ?>
            <div class="alert">
                <?php echo e(session('success')); ?>

                <?php if(old('name') || old('email') || old('message')): ?>
                    <div class="submitted-data">
                        <h3>Données soumises :</h3>
                        <p><strong>Nom :</strong> <?php echo e(old('name')); ?></p>
                        <p><strong>Email :</strong> <?php echo e(old('email')); ?></p>
                        <p><strong>Message :</strong> <?php echo e(old('message')); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>
</main>

<style>
    .alert {
        padding: 15px;
        margin: 20px 0;
        border-radius: 5px;
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    .submitted-data {
        margin-top: 15px;
        padding: 10px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 5px;
    }
    .submitted-data p {
        margin: 5px 0;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\oradi\resources\views/contact.blade.php ENDPATH**/ ?>